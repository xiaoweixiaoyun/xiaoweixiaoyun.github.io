package com.xiaowei;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.printing.PDFPrintable;
import org.apache.pdfbox.printing.Scaling;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.attribute.Attribute;
import javax.print.attribute.HashPrintRequestAttributeSet;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class PrintUtil {

    /**
     * @param filepath      文件地址
     * @param printService  打印服务
     * @param scaling       缩放形式
     * @param copies        打印份数
     * @param orientation   方向
     * @param sides         单双页
     * @param mediaSizeName 纸张大小
     * @param width         纸张宽度像素
     * @param height        纸张高度像素
     * @param marginLeft    距左边距离
     * @param marginRight   距右边距离
     * @param marginTop     距上边距离
     * @param marginBottom  距下边距离
     * @return true:成功 false：失败
     */
    public static boolean print(String filepath, PrintService printService, Scaling scaling, Integer copies, int orientation, Attribute sides, Attribute mediaSizeName
            , int width, int height, int marginLeft, int marginRight, int marginTop, int marginBottom) {
        PDDocument document = null;
        File file;
        try {
            file = new File(filepath);
            if (!file.exists()) {
                return false;
            }
            document = PDDocument.load(file);
            PrinterJob printerJob = PrinterJob.getPrinterJob();
            printerJob.setJobName(file.getName());
            printerJob.setPrintService(printService);
            PDFPrintable pdfPrintable = new PDFPrintable(document, scaling);
            Book book = new Book();
            PageFormat pageFormat = new PageFormat();
            pageFormat.setOrientation(orientation);
            Paper paper = getPaper(width, height, marginLeft, marginRight, marginTop, marginBottom);
            pageFormat.setPaper(paper);
            book.append(pdfPrintable, pageFormat, document.getNumberOfPages());
            printerJob.setPageable(book);
            printerJob.setCopies(copies);
            HashPrintRequestAttributeSet attributes = new HashPrintRequestAttributeSet();
            attributes.add(sides);
            attributes.add(mediaSizeName);
            printerJob.print(attributes);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (document != null) {
                try {
                    document.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }

    /**
     * 获取本地的打印服务列表
     */
    public static HashMap<String, PrintService> selectPrintService() {
        HashMap<String, PrintService> serviceMap = new LinkedHashMap<>();
        PrintService defaultPrintService = PrintServiceLookup.lookupDefaultPrintService();
        if (defaultPrintService != null) {
            serviceMap.put(defaultPrintService.getName(), defaultPrintService);
        }
        PrintService[] printServices = PrinterJob.lookupPrintServices();
        for (PrintService printService : printServices) {
            String value = printService.getName();
            if (defaultPrintService != null && !defaultPrintService.getName().equals(value)) {
                serviceMap.put(value, printService);
            }
        }
        return serviceMap;
    }


    private static Paper getPaper(int width, int height, int marginLeft, int marginRight, int marginTop, int marginBottom) {
        Paper paper = new Paper();
        paper.setSize(width, height);
        paper.setImageableArea(marginLeft, marginRight, width - (marginLeft + marginRight), height - (marginTop + marginBottom));
        return paper;
    }
}
