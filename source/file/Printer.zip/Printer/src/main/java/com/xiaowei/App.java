package com.xiaowei;

import com.xiaowei.view.PrintFrame;
import org.apache.pdfbox.printing.Scaling;

import javax.print.PrintService;
import javax.print.attribute.standard.MediaSizeName;
import javax.print.attribute.standard.Sides;
import java.awt.print.PageFormat;
import java.util.HashMap;

/**
 * 代用本地打印机打印PDF文件
 */
public class App {
    public static void main(String[] args) {
        String filepath = "test.pdf";
        // 本地调试
        new PrintFrame(filepath);

//        // 使用示例
//        // 1.获取服务列表
//        HashMap<String, PrintService> printServiceHashMap = PrintUtil.selectPrintService();
//        // 2.调用打印
//        boolean flag = PrintUtil.print(filepath, printServiceHashMap.get("导出为WPS PDF"), Scaling.ACTUAL_SIZE, 1,
//                PageFormat.PORTRAIT, Sides.ONE_SIDED,
//                MediaSizeName.ISO_A4, 595, 842,
//                12, 12, 12, 12);
//        // 3.返回结果
//        System.out.println(flag);
    }
}
